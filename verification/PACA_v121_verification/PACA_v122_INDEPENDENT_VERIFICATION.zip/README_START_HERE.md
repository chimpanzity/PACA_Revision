# PACA v122 — independent statistical verification (now including GLMM & Brown–Rosenthal)

You are an independent verifier. This self-contained package lets you REPRODUCE and CHECK the
statistics reported in the manuscript `manuscript/Protean_LLM_Writeup_v122.docx`, from the bundled
data, using your own code execution.

## Setup
    pip install -r requirements.txt        # numpy, pandas, scipy, statsmodels
Python 3.10+.

## Run these (from the package root)
1) Core claims (fast, ~10 s) — counts, main frame effect (paired t, exact Wilcoxon, exact sign test,
   95% CI, leave-one-model-out / leave-one-family-out), counterbalanced replication + Holm, human
   trace-audit precision/recall + 100k session-within-model bootstrap (seed 20260717) + inter-coder
   kappa, Figure-2 exact binomial, and the trace category counts. Prints PASS/FAIL against
   EXPECTED_RESULTS.json and writes my_results.json.
       python code/run_verification.py

2) Trace conditional model (~20 s) — session-clustered logistic ORs and adjusted probabilities.
   Reproduces OR .468 / .490 / 1.442 and the 80.x% unconditional rates.
       python code/verify_trace_pool.py

3) Appendix A null calibration of Proteus (~1 min) — runs the FROZEN opponent
   (code/proteus_committed.py) for 1,000 null sessions plus myopic/feeding agents.
       python code/verify_calibration.py

4) Brown–Rosenthal Table 4 (~2 min) — per-session sequential-dependency logits from the compact
   trial-level dataset. Reproduces Own-block significance counts and lag-1 own coefficients.
       python code/verify_brown_rosenthal.py

5) GLMM (~30 s) — the manuscript's complementary trial-level mixed model, from the compact dataset.
       python code/verify_glmm.py

## What to confirm
- run_verification prints "PASS N / N". Any FAIL: report the claim_id, your value, and the expected
  value, and trace the cause. Do NOT tune to match.
- verify_trace_pool ORs match the manuscript.
- verify_calibration null characteristics match Appendix A (activation ~12%, per-channel decline,
  opponent reward ~.500, episodes ~1.9, myopic ~.501). NOTE the feeding result: v122 states a
  feed-and-harvest agent reaches ~.55–.57 (this was open item D-01, now resolved in the manuscript;
  see DISCREPANCY_LOG.md). Please report your feeding result independently.
- verify_brown_rosenthal: Own-block and Opp-block DIRECTION reproduce (opponent tracking present
  under minimalist, suppressed under informed) and lag-1 own coefficients match. The Outcome column
  and a few borderline minimalist Own cells may differ by 1–3 sessions of 7 — the manuscript notes the
  original executable coder was not recovered, so exact thresholding is not fully determinable.
- verify_glmm: the informed effect is negative with OR ≈ 0.63, consistent with the −0.109 primary
  frame effect. The paper prints no numeric GLMM estimate (it is a complementary summary); the exact
  random-slope Laplace model needs R/lme4 and the script prints the glmer formula for that.

## Ground truth and rules
- EXPECTED_RESULTS.json — full-precision canonical + manuscript-rounded values + tolerances.
- CLAIM_LEDGER_MASTER.(csv/md) — every checked claim, its location, definition, and expected value.
- COMPARISON_RULES.md — exact vs tolerance rules.
- CALIBRATION_SPEC.md — Appendix A methodology.
- DATA_DICTIONARY_trials_compact.md — columns of the compact trial-level dataset.
- DISCREPANCY_LOG.md — resolved and open discrepancies (incl. D-01 feeding).

## Data (bundled, small)
- data/trials_compact.csv — compact TRIAL-LEVEL data: 30,800 rows (98 main + 56 counterbalanced
  sessions × 200 trials), only the fields needed for GLMM / Brown–Rosenthal / frame effect /
  replication. See DATA_DICTIONARY_trials_compact.md.
- data/sessions.csv — per-session main + supplemental summaries.
- data/counter_sessions.csv — the 56 counterbalanced sessions with pair metadata.
- data/trace_pool.csv — the informed-Anthropic sessions, trials 1–200, with response_text.
- data/resolved_labels.csv, data/audit150_key_SEALED.csv — the 150-item human audit + automatic key.
The 220 MB raw per-session corpus and the compiled workbook are NOT bundled; these CSVs are exact
extracts sufficient for every claim in scope.

## Scope note
Supplemental ablation/temperature/order analyses (Tables D/E) are not included in the compact dataset
(authoritative source is the workbook Supp_Trials sheet). The inferential backbone, integrity counts,
replication, human audit, trace (unconditional + conditional), Appendix A calibration, Brown–Rosenthal
Table 4, and the GLMM ARE covered.
