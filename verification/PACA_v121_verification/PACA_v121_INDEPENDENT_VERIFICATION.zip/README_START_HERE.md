# PACA v121 — independent statistical verification (everything except the GLMM)

You are an independent verifier. This self-contained package lets you REPRODUCE and CHECK the
statistics reported in the manuscript `manuscript/Protean_LLM_Writeup_v121.docx`, from the bundled
data, using your own code execution. The GLMM is intentionally OUT OF SCOPE (deferred).

## Setup
    pip install -r requirements.txt        # numpy, pandas, scipy
Python 3.10+.

## Run these three (from the package root)
1) Core claims (fast, ~10 s) — counts, main frame effect (paired t, exact Wilcoxon, exact sign test,
   95% CI, leave-one-model-out / leave-one-family-out), counterbalanced replication + Holm, human
   trace-audit precision/recall + 100k session-within-model bootstrap (seed 20260717) + inter-coder
   kappa, Figure-2 exact binomial, and the trace category counts. Prints PASS/FAIL against
   EXPECTED_RESULTS.json and writes my_results.json.
       python code/run_verification.py

2) Trace conditional model (~20 s) — the session-clustered logistic ORs and adjusted probabilities.
   Should reproduce OR .468 / .490 / 1.442 and the 80.x% unconditional rates.
       python code/verify_trace_pool.py

3) Appendix A null calibration of Proteus (~1 min) — runs the FROZEN opponent (code/proteus_committed.py)
   for 1,000 null sessions plus myopic/feeding agents.
       python code/verify_calibration.py

## What to confirm
- run_verification prints "PASS N / N". Any FAIL: report the claim_id, your value, and the expected
  value, and trace the cause (input, formula, coding, rounding, randomness). Do NOT tune to match.
- verify_trace_pool ORs match the manuscript.
- verify_calibration null characteristics match Appendix A (any-channel activation ~12%, per-channel
  rates declining with lag, opponent reward ~.500, episodes ~1.9 trials, myopic ~.501).
  KNOWN OPEN ITEM (see DISCREPANCY_LOG.md, D-01): the manuscript says feeding "never exceeded .49";
  this package's feed-and-harvest policy reaches ~.57. Please report your feeding result independently.

## Ground truth and rules
- EXPECTED_RESULTS.json — full-precision canonical + manuscript-rounded values + tolerances.
- CLAIM_LEDGER_MASTER.(csv/md) — every checked claim, its location, definition, and expected value.
- COMPARISON_RULES.md — exact vs tolerance rules (exact for counts/exact tests; fixed-seed bootstrap
  exact; deterministic stats within 1e-6; fresh-seed sims within Monte Carlo error).
- ANALYSIS methodology is described in CALIBRATION_SPEC.md (Appendix A) and the ledger definitions.

## Data (bundled, small)
- data/sessions.csv — per-session main + supplemental (win_rate, P_triangle, runs_z, activation, trials).
- data/counter_sessions.csv — the 56 counterbalanced sessions with pair metadata.
- data/trace_pool.csv — the 21 informed-Anthropic sessions, trials 1-200, with response_text.
- data/resolved_labels.csv, data/audit150_key_SEALED.csv — the 150-item human audit + automatic key.
The 220 MB raw per-session corpus and the 40 MB compiled workbook are NOT bundled (size); these CSVs
are exact extracts sufficient for every everything-except-GLMM claim.

## Scope note
GLMM excluded by request. Descriptive per-cell tables (D1/D2/E1/E2) and Brown-Rosenthal per-cell
counts (Table 2) are not in this tranche; the inferential backbone, integrity counts, replication,
human audit, trace (unconditional + conditional), and Appendix A calibration ARE.
