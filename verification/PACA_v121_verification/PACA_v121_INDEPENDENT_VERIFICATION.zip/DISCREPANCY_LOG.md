# DISCREPANCY_LOG.md
Canonical self-test on the frozen workbook. No discrepancies in the reproduced tranche.

| claim group | canonical vs manuscript | status |
|---|---|---|
| Integrity counts (98/19,600/238/47,600/56/11,200) | identical | EXACT |
| Main frame effect (mean −.109; six of seven negative) | −.1090; 6/7 | EXACT (display) |
| Main exact Wilcoxon (W=2, p=.047) / sign test (p=.125) / t(6) CI [−.205,−.013] | reproduced | MATCH beyond display |
| Leave-one-model-out / leave-one-family-out stability | reproduced | computed |
| Replication (pooled −.139; t(6)=−2.93; p=.027; CI [−.255,−.023]; 6/7; 3 survive Holm) | reproduced | EXACT (display) |
| Human audit precision .865/.865/.802 (+CIs) ; recall 1.00/1.00/.938 | reproduced (seed 20260717, 100k) | MATCH |
| Inter-coder kappa .97/.93/.64 (3-way, Uncertain as category) | .9726/.9310/.6406 | EXACT (display) |
| Figure-2 example 19/26=.7308; exact binomial p=.0289592743→.029 | identical | EXACT |
| Trace conditional ORs (.468/.490/1.442) | consolidated from frozen verify_trace | to re-run under analysis_v121 |
| GLMM | not computed | DEFERRED (author) |

## D-01 (Appendix A, feeding counter-policy) — OPEN, do not resolve unilaterally
Manuscript: "Tested agents that incurred losses to 'feed' a false bias and later exploit it never
exceeded .49." Independent reimplementation of a feed-and-harvest policy (feed one side 20-60 trials,
then best-respond to the strongest active channel), 100 sessions/config, seeds 9500+s, against the
FROZEN committed opponent, reached subject reward .55-.57 (max .574) - i.e., ABOVE .49 and above the
.500 benchmark. Mechanism: the cumulative side-bias channel keeps predicting the fed side after the
agent switches, so the harvest window outweighs the feeding losses.
- Does NOT affect the main result (tested LLMs still won < .5) and falls within Appendix A's own hedge
  that a more sophisticated policy might exploit the fixed algorithm.
- DOES contradict the specific "never exceeded .49" sentence.
- Resolution needed from author: the exact feeding policies they tested (for like-for-like), OR a
  softening of that sentence. Not changed here.
- Null operating characteristics (activation ~12%, per-channel decline, reward .500, episodes 1.9,
  myopic .501) all reproduced.
